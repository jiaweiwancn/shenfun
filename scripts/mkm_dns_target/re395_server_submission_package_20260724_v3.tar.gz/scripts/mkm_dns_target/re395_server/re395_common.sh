#!/bin/bash
# Shared, source-only configuration for Re_tau=395 SLURM jobs.

INSTALL=/share/home/dkyzdsys_wanjiawei/shenfun_offline_centos_install
ENV="$INSTALL/env"
REPO=/share/home/dkyzdsys_wanjiawei/shenfun-master
RUN_ROOT=/share/home/dkyzdsys_wanjiawei/shenfun_runs/re395
LOG_ROOT=/share/home/dkyzdsys_wanjiawei/shenfun_runs/logs

RUNNER="$REPO/scripts/mkm_dns_target/run_mkm_dns.py"
VALIDATOR="$REPO/scripts/mkm_dns_target/validate_mkm_state_roundtrip.py"
STATE_AUDITOR="$REPO/scripts/mkm_dns_target/inspect_mkm_state_shards.py"
PROFILE="$REPO/scripts/mkm_dns_target/data/chan395.means"
PROFILE_SHA256=211c6b8149cc7ef5cd20323716b47a45dd98cca55486a9554acfd4a7975d737a

RE_TAU=395
BULK_VELOCITY=17.54475114359453
DNS_DT=0.00025
PADDING_WALL=1.5
PADDING_STREAM=1.5
PADDING_SPAN=1.5

activate_re395_runtime() {
    local run_dir=$1

    # Conda activation may inspect variables that are unset.  The calling
    # SLURM scripts deliberately defer nounset until activation has completed.
    # The updated activation helper is also safe if a caller already uses
    # nounset, so this remains a defence-in-depth boundary.
    source "$INSTALL/activate_shenfun.sh"
    set -u
    export OMP_NUM_THREADS="${SLURM_CPUS_PER_TASK:-1}"
    export OPENBLAS_NUM_THREADS=1
    export MKL_NUM_THREADS=1
    export NUMEXPR_NUM_THREADS=1
    export MPLBACKEND=Agg
    export MPLCONFIGDIR="$run_dir/mplconfig"
    export TMPDIR="$run_dir/tmp"
    mkdir -p "$MPLCONFIGDIR" "$TMPDIR"

    # MKM imports pyplot on every MPI rank even when plotting is disabled.
    # Populate the font cache once, before mpiexec, so a first high-rank job
    # cannot race on Matplotlib's shared cache lock.
    "$ENV/bin/python" -c \
        "import matplotlib.pyplot; print('matplotlib_cache_ready')"
}

verify_re395_inputs() {
    test -x "$ENV/bin/python"
    test -f "$RUNNER"
    test -f "$VALIDATOR"
    test -f "$STATE_AUDITOR"
    test -f "$PROFILE"
    printf '%s  %s\n' "$PROFILE_SHA256" "$PROFILE" | sha256sum --check -
}

print_re395_provenance() {
    local run_dir=$1

    printf 'timestamp_utc=%s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
    printf 'job_id=%s\n' "${SLURM_JOB_ID:-not-in-slurm}"
    printf 'node_list=%s\n' "${SLURM_JOB_NODELIST:-not-in-slurm}"
    printf 'mpi_ranks=%s\n' "${SLURM_NTASKS:-1}"
    printf 'run_dir=%s\n' "$run_dir"
    printf 'repo=%s\n' "$REPO"
    printf 'runner=%s\n' "$RUNNER"
    "$ENV/bin/python" -V
    "$ENV/bin/python" -c \
        "import h5py, numpy, scipy, shenfun; print('versions', shenfun.__version__, numpy.__version__, scipy.__version__, h5py.__version__, 'h5py_mpi='+str(h5py.get_config().mpi))"
    "$ENV/bin/python" -c \
        "from mpi4py import MPI; print(MPI.Get_library_version().splitlines()[0])"
    git -C "$REPO" rev-parse HEAD || true
    git -C "$REPO" status --short || true
}

run_re395_mpi() {
    HYDRA_LAUNCHER=fork "$ENV/bin/mpiexec" -n "$SLURM_NTASKS" "$@"
}
