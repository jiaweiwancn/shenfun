# Re_tau=395 CentOS/SLURM submission package

## Material Passport

- Origin Skill: experiment-agent
- Origin Mode: run preparation
- Origin Date: 2026-07-24
- Verification Status: Ubuntu numerical/I/O gates verified; CentOS execution pending
- Version Label: re395_server_jobs_v3

## Execution status

These files prepare the updated all-plane plan for the CentOS 7 server.  The
same solver, writer, validator, and auditor passed the numerical and HDF5 gates
in an isolated copy on the Ubuntu server.  CentOS/SLURM execution is still a
separate gate: run the small even-grid round trip there first and return its
bundle for inspection.  Do not submit spin-up or stationary production until
the CentOS small-grid and full-shape pilots have passed.

The package assumes the validated paths from
`HANDOFF_SHENFUN_SERVER_JOB_SUBMISSION.md`:

```text
repository  /share/home/dkyzdsys_wanjiawei/shenfun-master
environment /share/home/dkyzdsys_wanjiawei/shenfun_offline_centos_install/env
partition   cpu02
launcher    HYDRA_LAUNCHER=fork, one node only
```

## Files that must be copied to the server repository

Preserve their repository-relative paths:

```text
demo/MKM.py
scripts/mkm_dns_target/run_mkm_dns.py
scripts/mkm_dns_target/mkm_state_io.py
scripts/mkm_dns_target/validate_mkm_state_roundtrip.py
scripts/mkm_dns_target/inspect_mkm_state_shards.py
scripts/mkm_dns_target/data/chan395.means
scripts/mkm_dns_target/re395_server/*
```

The official profile checksum is:

```text
211c6b8149cc7ef5cd20323716b47a45dd98cca55486a9554acfd4a7975d737a
```

Source:
`https://turbulence.oden.utexas.edu/data/MKM/chan395/profiles/chan395.means`
(retrieved 24 July 2026). The bundled file is unchanged.

The job scripts verify this checksum before running.

## One-time server preparation

On the login node:

```bash
mkdir -p /share/home/dkyzdsys_wanjiawei/shenfun_runs/logs
mkdir -p /share/home/dkyzdsys_wanjiawei/shenfun_runs/re395

cd /share/home/dkyzdsys_wanjiawei/shenfun-master
source /share/home/dkyzdsys_wanjiawei/shenfun_offline_centos_install/activate_shenfun.sh

python scripts/mkm_dns_target/run_mkm_dns.py --help
python scripts/mkm_dns_target/validate_mkm_state_roundtrip.py --help
python scripts/mkm_dns_target/inspect_mkm_state_shards.py --help
sha256sum scripts/mkm_dns_target/data/chan395.means

bash -n scripts/mkm_dns_target/re395_server/*.sh
bash -n scripts/mkm_dns_target/re395_server/*.sbatch
```

Do not install or update packages in the offline environment.

The jobs require the nounset-safe activation helper distributed with the
updated CentOS handoff.  Its checksum is:

```text
cbc2b58388e5dea858f0d861ebbd7607a1a9a4c06633a9957870a8e5c6f854dd
```

Verify the copied install support files before submitting:

```bash
cd /share/home/dkyzdsys_wanjiawei/shenfun_offline_centos_install
sha256sum -c SHA256SUMS
```

Each SLURM script starts with `set -eo pipefail`.  The shared runtime activates
the relocated environment and then immediately enables `set -u`.  This ordering
avoids the generated Conda activation script reading an unset `CONDA_PREFIX`,
while retaining strict nounset checking for the simulation itself.

The shared runtime also imports Matplotlib once before `mpiexec`.  This
serially creates the per-run font cache and prevents a first high-rank launch
from contending for the same `fontlist` lock file.

## Ubuntu verification record

The upload candidate was tested in an isolated repository copy at
`/media/jay/data1/tmp/re395_n192_validation_fEdJVNep/repo`; the existing
Ubuntu repository and production data were not modified.  The environment
used Shenfun 4.3.0, NumPy 1.26.4, SciPy 1.15.2, h5py 3.11 with MPI, and MPICH
4.2.1.

Verified on 24 July 2026:

- the 4-rank `(18,32,24)` test completed 40 steps and 20 paired samples,
  with zero physical reconstruction error, no NaN/Inf, and maximum divergence
  `1.26e-15`;
- the full `(192,256,192)` shape with padded `(288,384,288)` completed two
  DNS steps at 16, 32, and 64 ranks;
- the 64-rank full-shape I/O test reconstructed all 192 planes from one
  independent-state sample, with maximum absolute component error
  `2.14e-14`, maximum relative error `1.06e-15`, maximum divergence
  `9.53e-16`, and no NaN/Inf;
- the measured full-shape state file was `152,594,328` bytes and its paired
  physical velocity file was `226,523,696` bytes; and
- a reduced spin-up plus two consecutive sampling segments passed checkpoint
  restart, velocity-file append, two state-shard continuity checks, and exact
  reconstruction for all eight retained samples.

The first 64-rank attempt exposed a Matplotlib font-cache lock race before the
solver imported.  The serial cache warm-up in `re395_common.sh` fixed that
startup defect; the corrected 64-rank rerun passed.  These are functional
pilots, not a stationarity or turbulence-resolution validation.

## Why the package now uses an even wall-normal size

The MKM reference table uses 193 wall-normal points in its endpoint-including
Chebyshev convention.  Shenfun's optimized Chebyshev biharmonic solver splits
the coefficient system into equal even/odd parity blocks.  A real four-rank
test with `N_wall=17` initialized successfully but generated non-finite
coefficients in the first Runge--Kutta substage.  Its matched `N_wall=18`
control remained finite and passed the exact all-plane state round trip.

The selected Shenfun production size is therefore `N_wall=192`.  This is less
than the paper's count by one point (about 0.52 percent), retains 14 saved
points per wall below `y+=10`, and is compatible with the current solver.
The runner rejects odd Chebyshev wall sizes before allocation.

## Gate A: small even-grid round trip

Submit this first:

```bash
cd /share/home/dkyzdsys_wanjiawei/shenfun-master/scripts/mkm_dns_target/re395_server
JOB_ID=$(sbatch --parsable 01_small_even_roundtrip.sbatch | cut -d';' -f1)
echo "$JOB_ID"
```

Monitor:

```bash
squeue -j "$JOB_ID"
tail -f /share/home/dkyzdsys_wanjiawei/shenfun_runs/logs/mkm395_small_rt_${JOB_ID}.out
tail -f /share/home/dkyzdsys_wanjiawei/shenfun_runs/logs/mkm395_small_rt_${JOB_ID}.err
sacct -j "$JOB_ID" --format=JobID,JobName,State,ExitCode,Elapsed,AllocCPUS,NodeList
```

Expected terminal markers:

```text
"status": "PASS"
SMALL_EVEN_ROUNDTRIP_PASS
```

The test uses:

```text
mesh                  18 x 32 x 24
MPI ranks             4
DNS steps             40
dense/state cadence   every 2 steps
paired samples        20
state compression     none
```

It checks all 18 wall-normal planes and all three velocities, rejects any
NaN/Inf in both archives, and writes only small test data.

After completion, make a return bundle:

```bash
RUN_DIR=/share/home/dkyzdsys_wanjiawei/shenfun_runs/re395/test_small_even_${JOB_ID}
bash collect_test_bundle.sh "$JOB_ID" "$RUN_DIR" --include-h5
```

Copy `return_bundle_${JOB_ID}.tar.gz` back for inspection. The most important
files are the SLURM output/error logs, run-config JSON, round-trip JSON, state
HDF5, and conventional velocity HDF5.

### Optional small lossless-compression check

Only after the uncompressed test passes:

```bash
JOB_ID=$(sbatch --parsable \
  --export=ALL,STATE_COMPRESSION=gzip \
  01_small_even_roundtrip.sbatch | cut -d';' -f1)
echo "$JOB_ID"
```

This verifies exact decompression on a small job. It does not establish that
parallel gzip will scale efficiently at the production mesh.

## Gate B: full-shape allocation and decomposition

After Gate A is accepted:

```bash
JOB_ID=$(sbatch --parsable 02_fullshape_allocation.sbatch | cut -d';' -f1)
echo "$JOB_ID"
```

This runs two DNS steps at `(192,256,192)` with padded shape
`(288,384,288)`, 16 ranks, no velocity or temporal-state output, and a final
checkpoint. Return the SLURM logs and run-config JSON; the checkpoint need not
be copied back.

Repeat successful allocation tests with explicit rank overrides:

```bash
sbatch --ntasks=32 02_fullshape_allocation.sbatch
sbatch --ntasks=64 02_fullshape_allocation.sbatch
```

Do not assume 128 ranks work merely because the node offers 128 CPU slots.
The Ubuntu 64-rank result supports the current production-template default,
but the CentOS node still needs its own Gate B/C timing and memory evidence.

## Gate C: one-sample full-shape state I/O

After a full-shape rank count works:

```bash
JOB_ID=$(sbatch --parsable 02b_fullshape_state_io.sbatch | cut -d';' -f1)
echo "$JOB_ID"
```

Override `--ntasks` to the rank count accepted at Gate B if it differs from 16;
`--ntasks=64` is the first CentOS candidate because it passed the Ubuntu
full-shape allocation and I/O gates.
The job writes one conventional physical field and one independent-state
sample, then performs the same all-plane round trip. Expected marker:

```text
FULLSHAPE_STATE_IO_PASS
```

Return logs, run-config JSON, and round-trip JSON. The approximately
hundreds-of-MiB HDF5 files need not be copied back unless the JSON comparison
fails.

## Gate D: spin-up segments

This is a production template, not authorization to submit. Select the rank
count from Gates B/C and review the measured step time and memory first.

Initial segment to outer time 20:

```bash
sbatch --ntasks=64 \
  --export=ALL,END_TIME=20,FROM_CHECKPOINT=0 \
  03_spinup_segment.sbatch
```

Continuation to outer time 40:

```bash
sbatch --ntasks=64 \
  --export=ALL,END_TIME=40,FROM_CHECKPOINT=1 \
  03_spinup_segment.sbatch
```

`END_TIME` is absolute, not a duration. Continue through candidate review
times 20, 40, 60, and beyond as required. Each job:

- uses `dt=0.00025`;
- writes no velocity/state time series;
- checkpoints every 20,000 steps (five outer time units);
- reports energy, flux, divergence, two wall stresses, measured `Re_tau`, and
  a documented CFL estimate every 400 steps;
- forces a final checkpoint; and
- writes a job-tagged run-config JSON.

Stationarity acceptance still requires profile, stress, spectral-tail,
half-box-correlation, and symmetry review. Scalar log stability alone is not
sufficient.

## Gate E: stationary all-plane sampling

After a spin-up checkpoint is accepted, isolate it:

```bash
bash prepare_sampling_checkpoint.sh \
  /share/home/dkyzdsys_wanjiawei/shenfun_runs/re395/production_mkm_Re395_N192_256_192_spinup/MKM_Re395_N192_256_192_spinup.chk.h5
```

Suppose the accepted checkpoint is at `t=60`. The first ten-unit sampling job
is:

```bash
sbatch --ntasks=64 \
  --export=ALL,END_TIME=70,STATE_COMPRESSION=none \
  04_sampling_segment.sbatch
```

Continue with absolute end times 80, 90, and so on. A retained duration of at
least 120 outer time units requires 24,000 state samples.

The sampling template:

- saves the independent spectral state every 20 DNS steps
  (`Delta t_sample=0.005`);
- creates a closed state shard every 1,000 samples/five outer time units;
- uses complex128/float64 without wall-normal or modal truncation;
- saves a conventional audit field every 40,000 steps/ten outer time units;
- checkpoints every 20,000 steps/five outer time units; and
- refuses to overwrite existing state shards.

Use `STATE_COMPRESSION=none` for capacity and performance planning until the
gzip pilot is accepted. Compression is lossless but its ratio and parallel
write cost are empirical.

## Failure handling

- Do not resubmit blindly after any traceback, MPI abort, HDF5 error, nonzero
  SLURM exit code, or leftover `*.partial.h5`.
- Preserve the SLURM logs, checkpoint, completed state shards, and partial
  shard.
- Never rename a partial shard to a completed `.h5`.
- Do not overwrite the sampling checkpoint or audit file.
- Return a log/JSON bundle for diagnosis. Retry decisions are made after the
  failure is understood.

## Expected storage

At the production mesh:

```text
one independent-state sample          0.142093 GiB uncompressed
one 1,000-sample state shard         142.09 GiB uncompressed
24,000 samples / 120 outer units       3.3303 TiB uncompressed
equivalent dense velocity archive      4.9438 TiB uncompressed
```

Allow at least 5 TiB for the retained baseline record, checkpoints, audit
fields, derived outputs, and safety headroom, excluding any disposable
postprocessing cache.
