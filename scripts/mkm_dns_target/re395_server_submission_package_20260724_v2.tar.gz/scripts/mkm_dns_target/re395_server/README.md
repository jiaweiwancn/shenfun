# Re_tau=395 CentOS/SLURM submission package

## Material Passport

- Origin Skill: experiment-agent
- Origin Mode: run preparation
- Origin Date: 2026-07-24
- Verification Status: syntax/local-structure checked; server execution unverified
- Version Label: re395_server_jobs_v2

## Execution status

These files prepare the updated all-plane plan for the CentOS 7 server. They do
not claim that the new independent-state writer has passed an MPI/HDF5 run.
Run the small odd-grid round trip first and return its bundle for inspection.
Do not submit spin-up or stationary production until that result and the two
full-shape pilots have passed.

The package assumes the validated paths from
`HANDOFF_SHENFUN_SERVER_JOB_SUBMISSION.md`:

```text
repository  /share/home/dkyzdsys_wanjiawei/shenfun-master
environment /share/home/dkyzdsys_wanjiawei/shenfun_offline_centos_install/env
partition   cpu02
launcher    HYDRA_LAUNCHER=fork, one node only
```

## Files that must be copied to the server repository

Preserve their repository-relative paths:

```text
demo/MKM.py
scripts/mkm_dns_target/run_mkm_dns.py
scripts/mkm_dns_target/mkm_state_io.py
scripts/mkm_dns_target/validate_mkm_state_roundtrip.py
scripts/mkm_dns_target/inspect_mkm_state_shards.py
scripts/mkm_dns_target/data/chan395.means
scripts/mkm_dns_target/re395_server/*
```

The official profile checksum is:

```text
211c6b8149cc7ef5cd20323716b47a45dd98cca55486a9554acfd4a7975d737a
```

Source:
`https://turbulence.oden.utexas.edu/data/MKM/chan395/profiles/chan395.means`
(retrieved 24 July 2026). The bundled file is unchanged.

The job scripts verify this checksum before running.

## One-time server preparation

On the login node:

```bash
mkdir -p /share/home/dkyzdsys_wanjiawei/shenfun_runs/logs
mkdir -p /share/home/dkyzdsys_wanjiawei/shenfun_runs/re395

cd /share/home/dkyzdsys_wanjiawei/shenfun-master
source /share/home/dkyzdsys_wanjiawei/shenfun_offline_centos_install/activate_shenfun.sh

python scripts/mkm_dns_target/run_mkm_dns.py --help
python scripts/mkm_dns_target/validate_mkm_state_roundtrip.py --help
python scripts/mkm_dns_target/inspect_mkm_state_shards.py --help
sha256sum scripts/mkm_dns_target/data/chan395.means

bash -n scripts/mkm_dns_target/re395_server/*.sh
bash -n scripts/mkm_dns_target/re395_server/*.sbatch
```

Do not install or update packages in the offline environment.

The jobs require the nounset-safe activation helper distributed with the
updated CentOS handoff.  Its checksum is:

```text
cbc2b58388e5dea858f0d861ebbd7607a1a9a4c06633a9957870a8e5c6f854dd
```

Verify the copied install support files before submitting:

```bash
cd /share/home/dkyzdsys_wanjiawei/shenfun_offline_centos_install
sha256sum -c SHA256SUMS
```

Each SLURM script starts with `set -eo pipefail`.  The shared runtime activates
the relocated environment and then immediately enables `set -u`.  This ordering
avoids the generated Conda activation script reading an unset `CONDA_PREFIX`,
while retaining strict nounset checking for the simulation itself.

## Gate A: small odd-grid round trip

Submit this first:

```bash
cd /share/home/dkyzdsys_wanjiawei/shenfun-master/scripts/mkm_dns_target/re395_server
JOB_ID=$(sbatch --parsable 01_small_odd_roundtrip.sbatch | cut -d';' -f1)
echo "$JOB_ID"
```

Monitor:

```bash
squeue -j "$JOB_ID"
tail -f /share/home/dkyzdsys_wanjiawei/shenfun_runs/logs/mkm395_small_rt_${JOB_ID}.out
tail -f /share/home/dkyzdsys_wanjiawei/shenfun_runs/logs/mkm395_small_rt_${JOB_ID}.err
sacct -j "$JOB_ID" --format=JobID,JobName,State,ExitCode,Elapsed,AllocCPUS,NodeList
```

Expected terminal markers:

```text
"status": "PASS"
SMALL_ODD_ROUNDTRIP_PASS
```

The test uses:

```text
mesh                  17 x 32 x 24
MPI ranks             4
DNS steps             40
dense/state cadence   every 2 steps
paired samples        20
state compression     none
```

It checks all 17 wall-normal planes and all three velocities. It writes only
small test data.

After completion, make a return bundle:

```bash
RUN_DIR=/share/home/dkyzdsys_wanjiawei/shenfun_runs/re395/test_small_odd_${JOB_ID}
bash collect_test_bundle.sh "$JOB_ID" "$RUN_DIR" --include-h5
```

Copy `return_bundle_${JOB_ID}.tar.gz` back for inspection. The most important
files are the SLURM output/error logs, run-config JSON, round-trip JSON, state
HDF5, and conventional velocity HDF5.

### Optional small lossless-compression check

Only after the uncompressed test passes:

```bash
JOB_ID=$(sbatch --parsable \
  --export=ALL,STATE_COMPRESSION=gzip \
  01_small_odd_roundtrip.sbatch | cut -d';' -f1)
echo "$JOB_ID"
```

This verifies exact decompression on a small job. It does not establish that
parallel gzip will scale efficiently at the production mesh.

## Gate B: full-shape allocation and decomposition

After Gate A is accepted:

```bash
JOB_ID=$(sbatch --parsable 02_fullshape_allocation.sbatch | cut -d';' -f1)
echo "$JOB_ID"
```

This runs two DNS steps at `(193,256,192)` with padded shape
`(290,384,288)`, 16 ranks, no velocity or temporal-state output, and a final
checkpoint. Return the SLURM logs and run-config JSON; the checkpoint need not
be copied back.

Repeat successful allocation tests with explicit rank overrides:

```bash
sbatch --ntasks=32 02_fullshape_allocation.sbatch
sbatch --ntasks=64 02_fullshape_allocation.sbatch
```

Do not assume 128 ranks work merely because the node offers 128 CPU slots.

## Gate C: one-sample full-shape state I/O

After a full-shape rank count works:

```bash
JOB_ID=$(sbatch --parsable 02b_fullshape_state_io.sbatch | cut -d';' -f1)
echo "$JOB_ID"
```

Override `--ntasks` to the rank count accepted at Gate B if it differs from 16.
The job writes one conventional physical field and one independent-state
sample, then performs the same all-plane round trip. Expected marker:

```text
FULLSHAPE_STATE_IO_PASS
```

Return logs, run-config JSON, and round-trip JSON. The approximately
hundreds-of-MiB HDF5 files need not be copied back unless the JSON comparison
fails.

## Gate D: spin-up segments

This is a production template, not authorization to submit. Select the rank
count from Gates B/C and review the measured step time and memory first.

Initial segment to outer time 20:

```bash
sbatch --ntasks=64 \
  --export=ALL,END_TIME=20,FROM_CHECKPOINT=0 \
  03_spinup_segment.sbatch
```

Continuation to outer time 40:

```bash
sbatch --ntasks=64 \
  --export=ALL,END_TIME=40,FROM_CHECKPOINT=1 \
  03_spinup_segment.sbatch
```

`END_TIME` is absolute, not a duration. Continue through candidate review
times 20, 40, 60, and beyond as required. Each job:

- uses `dt=0.00025`;
- writes no velocity/state time series;
- checkpoints every 20,000 steps (five outer time units);
- reports energy, flux, divergence, two wall stresses, measured `Re_tau`, and
  a documented CFL estimate every 400 steps;
- forces a final checkpoint; and
- writes a job-tagged run-config JSON.

Stationarity acceptance still requires profile, stress, spectral-tail,
half-box-correlation, and symmetry review. Scalar log stability alone is not
sufficient.

## Gate E: stationary all-plane sampling

After a spin-up checkpoint is accepted, isolate it:

```bash
bash prepare_sampling_checkpoint.sh \
  /share/home/dkyzdsys_wanjiawei/shenfun_runs/re395/production_mkm_Re395_N193_256_192_spinup/MKM_Re395_N193_256_192_spinup.chk.h5
```

Suppose the accepted checkpoint is at `t=60`. The first ten-unit sampling job
is:

```bash
sbatch --ntasks=64 \
  --export=ALL,END_TIME=70,STATE_COMPRESSION=none \
  04_sampling_segment.sbatch
```

Continue with absolute end times 80, 90, and so on. A retained duration of at
least 120 outer time units requires 24,000 state samples.

The sampling template:

- saves the independent spectral state every 20 DNS steps
  (`Delta t_sample=0.005`);
- creates a closed state shard every 1,000 samples/five outer time units;
- uses complex128/float64 without wall-normal or modal truncation;
- saves a conventional audit field every 40,000 steps/ten outer time units;
- checkpoints every 20,000 steps/five outer time units; and
- refuses to overwrite existing state shards.

Use `STATE_COMPRESSION=none` for capacity and performance planning until the
gzip pilot is accepted. Compression is lossless but its ratio and parallel
write cost are empirical.

## Failure handling

- Do not resubmit blindly after any traceback, MPI abort, HDF5 error, nonzero
  SLURM exit code, or leftover `*.partial.h5`.
- Preserve the SLURM logs, checkpoint, completed state shards, and partial
  shard.
- Never rename a partial shard to a completed `.h5`.
- Do not overwrite the sampling checkpoint or audit file.
- Return a log/JSON bundle for diagnosis. Retry decisions are made after the
  failure is understood.

## Expected storage

At the production mesh:

```text
one independent-state sample          0.142833 GiB uncompressed
one 1,000-sample state shard         142.83 GiB uncompressed
24,000 samples / 120 outer units       3.3476 TiB uncompressed
equivalent dense velocity archive      4.9696 TiB uncompressed
```

Allow at least 5 TiB for the retained baseline record, checkpoints, audit
fields, derived outputs, and safety headroom, excluding any disposable
postprocessing cache.
